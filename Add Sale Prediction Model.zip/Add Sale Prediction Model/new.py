import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import FunctionTransformer
import pickle
model = pickle.load(open('LAB/linear_regression_model.pkl', 'rb'))

st.title("ADD Sale Prediction")
TV = st.text_input("Enter Sales from TV")
Radio = st.text_input("Enter Sales from TRadio")
Newspapper = st.text_input("Enter Sales from TNewspapper")
if st.button("predicted"):
    features = np.array([[TV,Radio,Newspapper]],dtype=np.float64)
    results = model.predict(features).reshape(1,-1)
    st.write("presdicted sales:: ,",results[0]) 